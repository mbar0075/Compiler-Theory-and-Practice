import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import Stats from 'three/examples/jsm/libs/stats.module'
import { GUI } from 'dat.gui'
import { Panel } from './panel.js'
import { VM, LogsLevel } from './vm.js'

//==========================-

let program_execution_done = false;
let pad_vm = undefined;

let slowdown = 1;
let slowdown_counter = 0;

const renderer = new THREE.WebGLRenderer()
const scene = new THREE.Scene()
let camera = undefined;
let logs_area = undefined;

let w = 36;
let h = 36;

let ll = undefined;

document.addEventListener("load", initialise() );

function initialise()
{
    //Rendering stuff starts here ***
    
    //const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100)
    //let div_element = document.getElementById("displayarea");
    var div_elem = document.getElementById('displayarea'),
        properties = window.getComputedStyle(div_elem, null),
        div_height = properties.height,
        div_width = properties.width;

    var disp_div_h = 480;
    var disp_div_w = 480;    

    if (div_height.endsWith('px')) disp_div_h = parseInt(div_height.substring(0, div_height.length-2));
    if (div_width.endsWith('px')) disp_div_w = parseInt(div_width.substring(0, div_width.length-2));

    //console.log("DIV ELEMENT W:" + disp_div_w + " H:" + disp_div_h);
    //console.log("Window IW: " + window.innerWidth + " IH:" + window.innerHeight);
    camera = new THREE.PerspectiveCamera(75, disp_div_w / disp_div_h, 0.1, 1000)
    //camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100)
    const camera_o = new THREE.OrthographicCamera(-20, 20, 20, -20, 0.1, 100);
    camera.position.z = 38

    //renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setSize(disp_div_w, disp_div_h);
    div_elem.appendChild(renderer.domElement)

    const controls = new OrbitControls(camera, renderer.domElement)

    window.addEventListener(
        'resize',
        () => {
            var div_elem = document.getElementById('displayarea'),
            properties = window.getComputedStyle(div_elem, null),
            div_height = properties.height,
            div_width = properties.width;

            var disp_div_h = 480;
            var disp_div_w = 480;    

            if (div_height.endsWith('px')) disp_div_h = parseInt(div_height.substring(0, div_height.length-2));
            if (div_width.endsWith('px')) disp_div_w = parseInt(div_width.substring(0, div_width.length-2));

            camera.aspect = disp_div_w / disp_div_h
            camera.updateProjectionMatrix()
            renderer.setSize(disp_div_w, disp_div_h)
            render()
        },
        false
    )

    const stats = Stats()
    //document.getElementById("displayarea").appendChild(stats.dom)
    //div_elem.appendChild(stats.dom);    

    //const gui = new GUI()
    //const cameraFolder = gui.addFolder('Camera')
    //cameraFolder.add(camera.position, 'z', 0, 100)
    //cameraFolder.open()

    //var obj = { run:function(){ pad_vm.load_program(); program_execution_done = false; }};
    //gui.add(obj,'run');

    //document.getElementById("my-gui-container").appendChild(gui.domElement);

    //===================================-
    //Panel + VM related stuff starts here


    //Create pixel art display (pad) panel and change the colours at the corners
    let pad_panel = new Panel(scene, w, h, 0x00ffff);
    pad_panel.updateRegion(0,0,1,1,0xff0000);
    pad_panel.updateRegion(w-1, h-1, 1, 1, 0x00ff00);
    //pad_panel.updateRegion(0, h-2, 2, 2, 0xaaaaaa);
    //pad_panel.updateRegion(w-2, 0, 2, 2, 0x0000ff);

    ll = LogsLevel.Full;

    //Create VM and load a sample program
    pad_vm = new VM(64000, pad_panel, ll);
    //pad_vm.create_test_program();

    pad_vm.update_log("=>>> logs start here\n", LogsLevel.Partial, false);
    //logs_area = document.getElementById('logsarea');
    //logs_area.textContent = "=>>> logs start here\n";

    animate();
}

var speed_slider = document.getElementById("myRange");
speed_slider.value = slowdown;

// Update the current slider value (each time you drag the slider handle)
speed_slider.oninput = function() {
  slowdown = speed_slider.value;
}

var log_picker = document.getElementById("log_type");
log_picker.oninput = function() {  
  //pad_vm.logs_level = parseInt(log_picker.value);
  if (parseInt(log_picker.value) == 0) pad_vm.log_level = LogsLevel.None;
  if (parseInt(log_picker.value) == 1) pad_vm.log_level = LogsLevel.Error;
  if (parseInt(log_picker.value) == 2) pad_vm.log_level = LogsLevel.Partial;
  if (parseInt(log_picker.value) == 3) pad_vm.log_level = LogsLevel.Full;
  if (parseInt(log_picker.value) == 4) pad_vm.log_level = LogsLevel.Console;
  //pad_vm.update_log("log change to " + log_picker.value, LogsLevel.Full, true);
}

const element1 = document.getElementById("StopBtn");
element1.addEventListener("click", pause);
function pause() { program_execution_done = !program_execution_done; 
                   element1.textContent = program_execution_done ? ">" : "||"; }

const element0 = document.getElementById("RunBtn");
element0.addEventListener("click", run);
function run() { pad_vm.load_program(); program_execution_done = false; element1.textContent = "||"; }

const element2 = document.getElementById("ResUpdateBtn");
element2.addEventListener("click", updateRes);
function updateRes() { 
    let r = document.getElementById("res").value.trim();
    if (r[0] == '(') r = r.substring(1);
    if (r[r.length-1] == ')') r = r.substring(0, r.length-1);
    console.log("==== " + r);
    let wh = r.split(",");
    console.log("===== " + wh)
    let _w = parseInt(wh[0]);
    let _h = parseInt(wh[1]);
    console.log(_w + " " + _h);
    if (!isNaN(_w) & !isNaN(_h))
    {
        w = _w;
        h = _h;
        pad_vm.panel.updatePanel(_w, _h);
        pad_vm.load_program();
        program_execution_done = false;  
    }
    else
    {
        pad_vm.update_log("Error parsing resultion field !! " + r + " " + _w + " " + _h, LogsLevel.Always, false);
    }
}


function animate() {
    requestAnimationFrame(animate)
    //controls.update()

    if (!program_execution_done & (slowdown_counter % slowdown == 0))
    //if (!program_execution_done)
    {
        pad_vm.execute_program().then(
            function(value) {
                pad_vm.update_log("=== " + value, LogsLevel.Console, true);
                if (value == "HALT" | value == "FINISH" | value == "TIMEOUT")
                {
                    if (value != "TIMEOUT")
                    {
                        program_execution_done = true;
                        pad_vm.update_log("[Program Execution] " + value, LogsLevel.Partial, true);
                    }
                    //logs_area.textContent += "[OK] " + value + "\n";
                } 
                else 
                { 
                    if (value.startsWith("ERROR"))
                    {
                        program_execution_done = true;
                        pad_vm.update_log("[Program Execution ERROR] " + value, LogsLevel.Console, true);
                        pad_vm.update_log("[ERROR]" + value.substring(5)  + "\n", LogsLevel.Error, true);
                    }
                }
            }
        );
    }
    
    if (!program_execution_done) slowdown_counter+=1; 
    
    /*
    //update random regions using random colours - panel testing \\:://
    if (Math.random() > 0.9)
    {
        var x_ = Math.floor(Math.random() * w);
        var y_ = Math.floor(Math.random() * h);
        var w_ = Math.floor(Math.random() * w-x_);
        var h_ = Math.floor(Math.random() * h-y_);
        var c_ = Math.floor(Math.random() * 0xfffff * 1000000).toString(16);
        pad_panel.updateRegion(x_, y_, w_, h_, '#' + c_.slice(0, 6))
    }
    */
    
    render()
    //stats.update()
}

function render() {
    renderer.render(scene, camera)
}

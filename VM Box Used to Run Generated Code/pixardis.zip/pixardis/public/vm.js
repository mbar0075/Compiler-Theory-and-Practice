import { Panel } from './panel.js'

const memory_initialisation_value = 0;   //TODO

const LogsLevel = {
	None: 0,
    Error: 1,
	Partial: 2,
	Full: 3,
    Console: 4,
    Always: -1
}

class Frame
{
    constructor(pf, l)
    {
        this.parent_frame = pf;     //refers to parent scope/frame
        this.locals = new Array();  //indices will be offsets for local variables.
        l.forEach(element => this.locals.unshift(element));

        //console.log("created frame with " + this.to_string());
    }

    add_local(l)
    {
        this.locals[this.locals.length] = l;
    }

    read_local_at_idx(i)
    {
        //console.log("Reading local at idx " + i);
        if (i<this.locals.length)
            return this.locals[i];
        else return undefined;
    }

    write_local_at_idx(i, v)
    {
        //let result = undefined;
        if (i<this.locals.length)
        {
            this.locals[i] = v;
        }
        //return result;
    }

    to_string()
    {
        let s = "[";
        this.locals.forEach(element => s += parseInt(element) + " ")
        return s + "]";
    }
}

class Memory
{
    constructor(h_size, s_size)
    {
        //A Heap - globally contiguous block of memory for variables
        //TODO - 2024 assignment

        //A Stack - storing of stack frames with local (to the function) variables
        this.stack = new Array();
    }

    clear()
    {
        this.stack.length = 0;
    }

    push_frame(f)
    {
        this.stack.unshift(f);
    }

    pop_frame()
    {
        this.stack.shift();
    }

    fetch_top_frame()
    {
        if (this.stack.length>0)
            return this.stack[0];
        else return undefined;
    }

    read_local_from_top_frame(i)
    {
        if (this.stack.length>0)
            return this.stack[0].read_local_at_idx(i);
        else return undefined;
    }

    read_local_from_frame(i, level)
    {
        //console.log("*************idx in frame = " + i + ", frame idx in stack = " + level + " current stack size = " + this.stack.length);
        //console.log("******frame contents = " + this.stack[level].toString())

        if (this.stack.length>level)
        {
            return this.stack[level].read_local_at_idx(i);
        }
        else return undefined;
    }

    write_local_to_top_frame(i, v)
    {
        if (this.stack.length>0)
            this.stack[0].write_local_at_idx(i, v);
    }

    write_local_to_frame(i, v, level)
    {
        if (this.stack.length>level)
            this.stack[level].write_local_at_idx(i, v);
    }

    to_string()
    {
        let s = ""
        this.stack.forEach(element => s + element.to_string())
        return s;
    }

    stack_size()
    {
        return this.stack.length;
    }

}

class Function 
{

    constructor(name, noi, nop, pc)
    {
        this.name = name;
        this.number_of_instructions = noi;
        this.number_of_parameters = nop;
        this.program_counter_first_inst = pc;
        this.return_present = false; 
    }

    to_string()
    {
        return "name: " + this.name + " " +
               "noi: " + this.number_of_instructions + " " + 
               "nop: " + this.number_of_parameters + " " +
               "pc: " + this.program_counter_first_inst + " " +
               "ret: " + this.return_present + ".";
    }

}

class Instruction 
{

    constructor(o, n, a, c, f)
    {
        this.op_code = o;
        this.name = n;
        this.arity = a;
        this.execute = f;
        this.cost = c;
    }

    to_string()
    {
        return "op_code: " + this.op_code + " " +
               "name: " + this.name + " " + 
               "arity: " + this.arity + "."
    }

}

class VM {

    constructor(memory_size, pad_panel, ll)
    {
        //initialise memory with 0s as default values
        this.memory = new Array(memory_size).fill(memory_initialisation_value);
        this.operand_stack = new Array();   //stack used by vm to carry out operand execution.
        this.address_stack = new Array();   //stack used by vm to keep track of return addresses (program counters) prior to function calls
        
        this.program = new Array();         //array storing the program (sequence of instructions)
        this.program_counter = 0;
        this.instruction_set = new Map();

        this.functions = new Map();     //map with all the functions in the program

        this.paused = 0;                //delay instruction sets this to delay  time in ms;
        this.paused_start = 0;          //record time Date.now() since start of delay
        this.halt = false;              //HALT instruction sets this to true
        this.error = false;             //All runtime errors set this to true ... program execution exits with  Err
        this.error_description = "";    //Set when runtime error occurs

        this.main_present = false;      //Is main function in program?

        this.timeout = 240;              //time in intructions cost availalbe to run a slice of the program / frame
        this.instr_cost = 0;            //cost of currently executing instruction

        this.panel = pad_panel;         //access to the pixel art panel

        this.memory = new Memory();     //points to memory stack and (eventually) heap

        this.log_level = ll;            //log level set from client.js

        this.#build_instruction_set();
    }

    create_test_program()
    {
        this.program[this.program.length] = ".main" 
        this.program[this.program.length] = "push 30";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "push 30";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "add";
        this.program[this.program.length] = "push 2000";
        this.program[this.program.length] = "delay";
        this.program[this.program.length] = "push 50";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "sub";
        this.program[this.program.length] = "push 27";
        this.program[this.program.length] = "min";
        this.program[this.program.length] = "push .rand100";    //.rand100 to function instruction pointer
        this.program[this.program.length] = "call";             //function call  
        this.program[this.program.length] = "halt";

        //function that generates a random number (0-100) and returns only when the random number > 80
        this.program[this.program.length] = ".rand100 0"; //number of parameters - pushed on the stack prior to calling   
        this.program[this.program.length] = "push #PC";   //pushing the program_counter (line number so far)
        this.program[this.program.length] = "push 48";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "push 48";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "pixel";
        this.program[this.program.length] = "push 100";
        this.program[this.program.length] = "irnd";
        this.program[this.program.length] = "push 90";
        this.program[this.program.length] = "gt";    
        this.program[this.program.length] = "cjmp";
        this.program[this.program.length] = "ret";

        this.#initialise_vm_state();
    }

    update_log(c, _ll, _append)
    {
        //console.log(_ll + " <= System:: " + this.log_level)
        if (_ll <= this.log_level)
        {
            let logs_area = document.getElementById('logsarea');
            if (_ll == LogsLevel.Console)
            {
                console.log(c)
            }
            else
            {
                logs_area.textContent = _append ? logs_area.textContent + c : c;
            }
        }
    }

    load_program()
    {
        this.program.length = 0;
        let t_program = document.getElementById("pad_program").value.split("\n");
        t_program.forEach(element => { if (element.replace(/\s/g, '') != "" && (!element.startsWith("//"))) this.program[this.program.length] = element.trim();  } )

        this.update_log("loaded program " + this.program, LogsLevel.Console, true);
        this.#initialise_vm_state();
    }

    #initialise_vm_state()
    {
        //check that there is a .main function that includes a halt instruction.
        let idx = 0;
        let noi = 0;
        let name = undefined;
        let logs_area = document.getElementById('logsarea');

        //logs_area.textContent = "=>>> logs start here\n";
        this.update_log("=>>> logs start here\n", LogsLevel.Always, false);

        this.functions.clear();

        while (idx < this.program.length)
        {
            let inst = this.program[idx].split(" "); 
            if (inst[0][0] == ".")
            {
                //this is the start of a function
                if (name != undefined) { this.functions.get(name).number_of_instructions = noi; }
                name = inst[0].substr(1);
                let nop = inst.length > 1 ? inst[1] : 0;
                let f = new Function(name, 0, nop, idx+1);   //first instruction of this function is the next one from this label
                this.functions.set(name, f);
                noi = 0; //reset the number of instructions count to 0
            }
            else
            {
                if (name == "main")
                {
                    if (inst[0] == "halt")
                    { 
                        this.functions.get(name).return_present = true;
                    }
                } 
                else
                {
                    if (inst[0] == "ret")
                    { 
                        this.functions.get(name).return_present = true;
                    }
                }

                noi++;
            }

            idx++;
        }

        this.halt = false;
        this.error = false;
        this.error_description = ""; 
        this.operand_stack.length = 0;
        this.address_stack.length = 0;

        if (name != undefined)
        {
            this.functions.get(name).number_of_instructions = noi;

            //set program counter to first instruction after .main
            let main_f = this.functions.get("main");
            if (main_f != undefined)
            {
                this.main_present = true;
                this.program_counter = main_f.program_counter_first_inst;
                this.update_log("Program Counter set to " + this.program_counter, LogsLevel.Console, true);
                if (main_f.return_present == false)
                {
                    console.log("[ERROR] MAIN function has no Halt instruction");
                    this.error = true;
                    this.error_description = "HALT instruction not present in .main";
                }
            }
            else
            {
                console.log("[ERROR] MAIN function not present");
                this.error = true;
                this.error_description = "Program does not included .main";
            }

            let rv = [false, ""];

            let f = function logMapElements(value, key, map) {
                        console.log("["+key + "] ==> " + value.to_string());
                        if (value.return_present == false)
                        {
                            rv[0] = true;
                            rv[1] = "RET instruction not present in ." + key;
                        }
                    }

            this.functions.forEach(f);

            if (rv[0])
            {
                this.error = true;
                this.error_description = rv[1];
            }

        }
        else
        {
            this.error = true;
            this.error_description = "hmmm giving up!! not sure why :(";
        }

    }

    #log_operand_stack()
    {
        this.update_log(this.operand_stack, LogsLevel.Console, true);
    }

    #to_string_operand_stack()
    {
        let s = "[ ";
        this.operand_stack.forEach(element => s += element + " ");
        s += "]"
        return s;
    }

    async execute_program()
    {
        let c_timeout = this.timeout;
        
        this.update_log("[PROGRAM EXEC] --> START/CONTINUE", LogsLevel.Console, true);

        this.update_log("[PROGRAM EXEC] --> Timeout = " + c_timeout + "\n", LogsLevel.Console, true);

        while ((this.program_counter < this.program.length) & !this.halt & c_timeout > 0 & !this.error)
        {
            if (this.paused == 0)
            {
                //console.log("[PC/TOTAL] --> " + this.program_counter + "/" + this.program.length);
                let i = this.program[this.program_counter]
                this.#execute_instruction(i)
                c_timeout -= this.instr_cost;
                this.#log_operand_stack()
            } 
            else
            {
                //decrement paused value until 0
                let cd = Date.now() - this.paused_start;
                c_timeout -= 1;
                if (cd > this.paused) {
                    this.update_log("[Resuming from DELAY] " + this.paused + "\n", LogsLevel.Full, true);
                    this.paused = 0;
                } 
            }
        }

        //if (this.program_counter == this.program.length) return "ERROR " + " No HALT instruction."

        if (this.error) return "ERROR " + this.error_description;

        if (!(c_timeout > 0)) return "TIMEOUT"

        if (this.halt) return "HALT"

        //console.log("[PROGRAM EXEC] --> FINISH")
        return "FINISH";
    }

    #execute_instruction(i)
    {
        let logs_area = document.getElementById('logsarea');
        
        this.update_log("[EXEC INSTR " + this.program_counter + "/" + this.program.length + "] " + i, LogsLevel.Console, true);
        
        let la = "[" + this.program_counter + "/" + this.program.length + "]";
        
        //remove comment if any
        let i_comments_split = i.split("//");
        
        let i_split = i_comments_split[0].trim().split(" ");

        //console.log("i_split = " + i_split);
        
        let result = undefined;
        let i0 = this.instruction_set.get(i_split[0]);
        if (i0 == undefined)
        {
            this.error = true;
            this.error_description = "Instruction not supported " + i_split[0];
        } 
        else
        {
            this.instr_cost = i0.cost;
            let i_arity = i0.arity;
            
            for (let t = 0; t<i_split.length; t++)
            {
                la += " " + i_split[t]
            }

            if (i_arity != i_split.length - 1)
            {
                this.update_log("Arity mismatch for instruction " + i_split[0], LogsLevel.Console, true);
                this.error = true;
                this.error_description = "Arity mismatch for " + i_split[0];
            }
            else
            {
                if (i_arity == 0)
                {
                    //console.log("[INSTRUCTION] " + i_split[0]) 
                    i0.execute(this, result);
                }

                if (i_arity == 1)
                { 
                    //console.log("[INSTRUCTION ARG1] " + i_split[1])
                    i0.execute(this, i_split[1], result);
                }

                if (i_arity == 2)
                { 
                    //console.log("[INSTRUCTION ARG1 ARG2] " + i_split[1] + " " + i_split[2]);
                    i0.execute(this, i_split[1], i_split[2], result);
                }
                this.update_log(la + " |=> " + this.#to_string_operand_stack() + "\n", LogsLevel.Full, true);
            }
        }
    }

    #build_instruction_set()
    {
        this.instruction_set.set("nop", 
            new Instruction(0, "nop", 0, 1, 
                function(vm, o) {
                    vm.program_counter++;
                }
            )
        );
        
        this.instruction_set.set("push", 
            new Instruction(1, "push", 1, 2, 
                function(vm, v, o) {
                    let pv = 0;
                    if (v.startsWith('#PC'))
                    {
                        //Check if an offset is included
                        let plus_off = v.split('+');
                        let minus_off = v.split('-');
                        let offset = 0;

                        if (plus_off.length == 2)
                        {
                            offset = parseInt(plus_off[1]);
                        }

                        if (minus_off.length == 2)
                        {
                            offset = parseInt(minus_off[1]) * -1;
                        }

                        pv = vm.program_counter + offset;
                    }
                    else
                    {
                        if (v[0] == '.')
                        {
                            //console.log("starts with . => " + v + " " + v.substr(1));
                            let f = vm.functions.get(v.substr(1));
                            if (f != undefined)
                            { 
                                pv = f.program_counter_first_inst;
                                //vm.program_counter = f.program_counter_first_inst;
                                //console.log("Program counter set to " + vm.program_counter);
                            }
                            else
                            {
                                vm.error = true;
                                vm.error_description = "Function " + v.substr(1) + " does not exist."
                            }    
                        }
                        else
                        {
                            if (v[0] == '#')
                            {
                                var hex = parseInt(v.replace(/^#/, ''), 16);
                                pv = hex;
                                //console.log(pv + " -hex-> " + pv.toString());
                            }
                            else
                            {
                                if (v[0] == '[')
                                {
                                    //load value from crt stack frame
                                    let i = parseInt(v.substring(1, v.length-1));
                                    let v_ = v.substring(1, v.length-1); //without []
                                    //console.log("-[]- push string = " + v + " ==== " + i);
                                    if (!isNaN(i) & !v_.includes(":"))
                                    {
                                        pv = vm.memory.read_local_from_top_frame(i);
                                        //console.log("from stack => " + pv)
                                    }
                                    else
                                    {
                                        //check if stack level is encoded in push operand
                                        let sl = v.substring(1, v.length-1).split(":");
                                        if (sl.length == 2)
                                        {
                                            let frame_idx = parseInt(sl[0]);
                                            let stack_idx = parseInt(sl[1]);
                                            //console.log("!!!READING " + frame_idx + " at stack idx  " + stack_idx);
                                            if ( !isNaN(frame_idx) & !isNaN(stack_idx) )
                                            {
                                                pv = vm.memory.read_local_from_frame(frame_idx, stack_idx);
                                            }
                                            else
                                            {
                                                this.error = true;
                                                this.error_description = "Unable to parse memory index to PUSH"    
                                            }
                                        }
                                        else
                                        {
                                            this.error = true;
                                            this.error_description = "Unable to parse memory index to PUSH"
                                        }
                                    }
                                }
                                else
                                {
                                    if (v.includes('.'))
                                        pv = parseFloat(v)
                                    else
                                        pv = parseInt(v);

                                    if (isNaN(pv))
                                    {
                                        this.error = true;
                                        this.error_description = "Unable to parse operand to PUSH"
                                    }
                                }
                            }
                        }
                    }

                    if (!this.error)
                    {
                        vm.operand_stack.unshift(pv); 
                        vm.program_counter++;
                    } 
                }
            )
        );

        this.instruction_set.set("drop", 
            new Instruction(2, "drop", 0, 2,
                function(vm, o) { 
                    o = vm.operand_stack.shift(); 
                    vm.program_counter++; 
                }
            )
        );

        this.instruction_set.set("add",
            new Instruction(3, "add", 0, 4,
                function(vm, o) { 
                    o = vm.operand_stack.shift() + vm.operand_stack.shift();
                    vm.operand_stack.unshift(o);
                    //console.log("ADD RESULT: " + o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("sub",
            new Instruction(4, "sub", 0, 4,
                function(vm, o) { 
                    o = vm.operand_stack.shift() - vm.operand_stack.shift();
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("mul",
            new Instruction(5, "mul", 0, 4,
                function(vm, o) { 
                    o = vm.operand_stack.shift() * vm.operand_stack.shift();
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("div",
            new Instruction(33, "div", 0, 4,
                function(vm, o) { 
                    o = vm.operand_stack.shift() / vm.operand_stack.shift();
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("and",
            new Instruction(33, "and", 0, 4,
                function(vm, o) { 
                    let op1 = vm.operand_stack.shift();
                    let op2 = vm.operand_stack.shift();
                    o = (op1 == 1 && op2 == 1) ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("or",
            new Instruction(34, "or", 0, 4,
                function(vm, o) { 
                    let op1 = vm.operand_stack.shift();
                    let op2 = vm.operand_stack.shift();
                    o = (op1 == 1 || op2 == 1) ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("not",
            new Instruction(36, "not", 0, 4,
                function(vm, o) { 
                    let op1 = vm.operand_stack.shift();
                    o = (op1 == 1) ? 0 : 1;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("inc",
            new Instruction(6, "inc", 0, 3,
                function(vm, o) { 
                    o = vm.operand_stack.shift()+1;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("dec",
            new Instruction(7, "dec", 0, 3,
                function(vm, o) { 
                    o = vm.operand_stack.shift()-1;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("max",
            new Instruction(8, "max", 0, 6,
                function(vm, o) { 
                    o = Math.max(vm.operand_stack.shift(), vm.operand_stack.shift());
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("min",
            new Instruction(9, "min", 0, 6,
                function(vm, o) { 
                    o = Math.min(vm.operand_stack.shift(), vm.operand_stack.shift());
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("lt",
            new Instruction(10, "lt", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() < vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("le",
            new Instruction(11, "le", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() <= vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("gt",
            new Instruction(12, "gt", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() > vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("ge",
            new Instruction(13, "gt", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() >= vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("eq",
            new Instruction(14, "eq", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() == vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("neq",
            new Instruction(35, "neq", 0, 6,
                function(vm, o) { 
                    o = vm.operand_stack.shift() != vm.operand_stack.shift() ? 1 : 0;
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );     

        this.instruction_set.set("delay",
            new Instruction(15, "delay", 0, 1,
                function(vm, o) { 
                    o = vm.operand_stack.shift();
                    vm.paused = o;
                    vm.paused_start = Date.now();
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("irnd",
            new Instruction(16, "irnd", 0, 6,
                function(vm, o) { 
                    o = Math.floor(Math.random()*vm.operand_stack.shift());
                    vm.operand_stack.unshift(o);
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("jmp",
            new Instruction(17, "jmp", 0, 2,
                function(vm, o) { 
                    o = vm.operand_stack.shift();
                    vm.program_counter = o;    //this needs to change when using bytecode
                }
            )
        );

        this.instruction_set.set("cjmp",
            new Instruction(18, "cjmp", 0, 4,
                function(vm, o) { 
                    o = vm.operand_stack.shift();
                    let jump_location = vm.operand_stack.shift();
                    vm.program_counter = o != 0 ? jump_location : vm.program_counter+1;
                }
            )
        );

        this.instruction_set.set("cjmp2",
            new Instruction(18, "cjmp2", 0, 4,
                function(vm, o) {
                    let jump_location = vm.operand_stack.shift(); 
                    o = vm.operand_stack.shift();
                    vm.program_counter = o != 0 ? jump_location : vm.program_counter+1;
                }
            )
        );

        this.instruction_set.set("ret",
            new Instruction(19, "ret", 0, 3,
                function(vm, o) { 
                    vm.program_counter = vm.address_stack.shift();
                    vm.memory.pop_frame();
                }
            )
        );

        this.instruction_set.set("call",
            new Instruction(20, "call", 0, 8,
                function(vm, o) { 
                    vm.address_stack.unshift(vm.program_counter+1);
                    vm.program_counter = vm.operand_stack.shift();
                    let locals_count = vm.operand_stack.shift();
                    //console.log("locals count: " + locals_count);
                    let locals_mem = new Array();
                    for (let i = 0; i < locals_count; i++) {
                        let v = vm.operand_stack.shift();
                        //console.log("value: " + v);
                        locals_mem.unshift(v);
                    }
                    let f = new Frame(vm.memory.fetch_top_frame(), locals_mem);
                    vm.memory.push_frame(f);
                    //console.log("MEM: " + vm.memory.to_string());
                    //console.log("Shifting PC to " + vm.program_counter + " and allocating space for " + locals_count + " variables");
                }
            )
        );

        this.instruction_set.set("halt",
            new Instruction(21, "halt", 0, 1,
                function(vm, o) {
                    vm.memory.clear(); 
                    vm.halt = true;
                }
            )
        );

        this.instruction_set.set("pixel",
            new Instruction(22, "pixel", 0, 2,
                function(vm, o) { 
                    let x = vm.operand_stack.shift();
                    let y = vm.operand_stack.shift();
                    let c = vm.operand_stack.shift();
                    vm.panel.updateRegion(x,y,1,1,'0x'+c.toString(16));
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("pixelr",
            new Instruction(23, "pixelr", 0, 2,
                function(vm, o) { 
                    let x = vm.operand_stack.shift();
                    let y = vm.operand_stack.shift();
                    let w = vm.operand_stack.shift();
                    let h = vm.operand_stack.shift();
                    let c = vm.operand_stack.shift();
                    vm.panel.updateRegion(x,y,w,h,'0x'+c.toString(16));
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("read",
            new Instruction(40, "read", 0, 2,
                function(vm, o) { 
                    let x = vm.operand_stack.shift();
                    let y = vm.operand_stack.shift();
                    console.log("x, y = " + x + "," + y)
                    let c = vm.panel.getPixelColour(x,y);
                    console.log("x, y = " + x + "," + y + " colour = " + c);
                    vm.operand_stack.unshift(parseInt(c, 16));
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("clear",
            new Instruction(24, "clear", 0, 24,
                function(vm, o) { 
                    let x = vm.operand_stack.shift();
                    //console.log("x = " + x);
                    //console.log("Back to hex ==> " + x.toString(16));
                    //stack should have a value of colour type #xxxxxxxx
                    vm.panel.updateRegion(0,0, vm.panel.width, vm.panel.height,'0x'+x.toString(16));
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("alloc",
            new Instruction(25, "alloc", 0, 1,
                function(vm, o) {
                    let locals_count = vm.operand_stack.shift();
                    //console.log("locals count: " + locals_count);
                    for (let i = 0; i < locals_count; i++) {
                        //let v = vm.operand_stack.shift();  //not passing values here.
                        //console.log("value: " + v);
                        vm.memory.fetch_top_frame().add_local(undefined);  //initially undefined
                    }
                    //console.log("MEM: " + vm.memory.to_string());
                    //console.log("Shifting PC to " + vm.program_counter + " and allocating space for " + locals_count + " variables"); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("oframe",
            new Instruction(26, "oframe", 0, 1,
                function(vm, o) {
                    let locals_count = vm.operand_stack.shift();
                    //console.log("locals count: " + locals_count);
                    let locals_mem = new Array();
                    for (let i = 0; i < locals_count; i++) {
                        //let v = vm.operand_stack.shift();  //not passing values here.
                        //console.log("value: " + v);
                        locals_mem.unshift(undefined);  //initially undefined
                    }
                    let f = new Frame(vm.memory.fetch_top_frame(), locals_mem);
                    vm.memory.push_frame(f);
                    console.log("MEM Frame counts " + vm.memory.stack_size());
                    //console.log("Shifting PC to " + vm.program_counter + " and allocating space for " + locals_count + " variables"); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("cframe",
            new Instruction(27, "cframe", 0, 1,
                function(vm, o) {
                    vm.memory.pop_frame();
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("st",
            new Instruction(28, "st", 0, 4,
                function(vm, o) {
                    let level = vm.operand_stack.shift();
                    let idx = vm.operand_stack.shift();
                    let val = vm.operand_stack.shift();
                    if (level == 0)
                    {
                        vm.memory.write_local_to_top_frame(idx, val);
                    }
                    else
                    {
                        vm.memory.write_local_to_frame(idx, val, level);
                    }
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("width",
            new Instruction(29, "width", 0, 1,
                function(vm, o) {
                    vm.operand_stack.unshift(vm.panel.width);
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("height",
            new Instruction(30, "height", 0, 1,
                function(vm, o) {
                    vm.operand_stack.unshift(vm.panel.height);
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("print",
            new Instruction(31, "print", 0, 1,
                function(vm, o) {
                    let m = vm.operand_stack.shift();
                    vm.update_log("-- " + m + "\n", LogsLevel.Always, true);
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("dup",
            new Instruction(32, "dup", 0, 1,
                function(vm, o) {
                    let m = vm.operand_stack.shift();
                    vm.operand_stack.unshift(m);
                    vm.operand_stack.unshift(m);
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("div",
            new Instruction(32, "div", 0, 2,
                function(vm, o) { 
                    o = vm.operand_stack.shift() / vm.operand_stack.shift();
                    vm.operand_stack.unshift(o); 
                    vm.program_counter++;
                }
            )
        );

        this.instruction_set.set("pixelr",
            new Instruction(33, "pixelr", 0, 5,
                function(vm, o) { 
                    let x = vm.operand_stack.shift();
                    let y = vm.operand_stack.shift();
                    let w = vm.operand_stack.shift();
                    let h = vm.operand_stack.shift();
                    let c = vm.operand_stack.shift();
                    vm.panel.updateRegion(x,y,w,h,'0x'+c.toString(16));
                    vm.program_counter++;
                }
            )
        );

        //console.log(this.instruction_set);

    }

}

export { VM, LogsLevel };
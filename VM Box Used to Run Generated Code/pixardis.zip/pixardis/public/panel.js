import * as THREE from 'three'

class Panel {

    static quad = new THREE.PlaneGeometry(1,1,1,1);
    static material_white = new THREE.MeshBasicMaterial({
                            color: 0xffffff,
                            wireframe: true,
                        }) 
                        
    grid = [];
    width = undefined;
    height = undefined;
    color = undefined;
    material = undefined;
    scene = undefined;                    

    constructor(s, w, h, c)
    {
        this.width = w;
        this.height = h;
        this.color = c;
        this.scene = s;

        this.material = new THREE.MeshBasicMaterial({color: this.color})

        this.buildPanel();
    }

    buildPanel()
    {
        if (this.width == undefined) this.width = 16;
        if (this.height == undefined) this.height = 16;
        if (this.material == undefined) this.material = material_white;

        console.log("Building Panel :: W " + this.width + "   H " + this.height);

        for (let h = 0; h < this.height; h++)
        {
            var row = [];
            for (let w = 0; w < this.width; w++)
            {
                //const q = new THREE.Mesh(Panel.quad, this.material)
                const q = new THREE.Mesh(Panel.quad, new THREE.MeshBasicMaterial({color: this.color}));
                q.position.x = -(this.width/2) + (w);
                q.position.y = -(this.height/2) + (h);
                q.scale.x = 0.9;
                q.scale.y = 0.9;
                q.scale.x = 1;
                q.scale.y = 1;
                row.push(q);
                this.scene.add(q);
            }
            this.grid.push(row);
        }

        console.log("GRID Length = " + this.grid.length)
    }

    updatePanel(new_w, new_h)
    {
        this.scene.clear();
        this.grid.length = 0;
        this.width = new_w;
        this.height = new_h;

        for (let h = 0; h < this.height; h++)
        {
            var row = [];
            for (let w = 0; w < this.width; w++)
            {
                //const q = new THREE.Mesh(Panel.quad, this.material)
                const q = new THREE.Mesh(Panel.quad, new THREE.MeshBasicMaterial({color: this.color}));
                q.position.x = -(this.width/2) + (w);
                q.position.y = -(this.height/2) + (h);
                q.scale.x = 0.9;
                q.scale.y = 0.9;
                row.push(q);
                this.scene.add(q);
            }
            this.grid.push(row);
        }
    }

    updateRegion(x,y,w,h,c)
    {
        //parseInt( inputFieldVal.substr( 1 ), 16
        //const c_ = new THREE.Color( c );
        //var newMaterial = new THREE.MeshBasicMaterial({color: c_})
        
        //var newMaterial = new THREE.MeshBasicMaterial()
        //newMaterial.color.setHex(parseInt(c), 16);
        let _c = parseInt(c);
        for (let _y = y; _y < Math.min(this.height,y+h); _y++)
        {
            for (let _x = x; _x < Math.min(this.width,x+w); _x++)
            {
                //if (this.grid[_x] == undefined)
                //{
                    //console.log("Updating::: " + _x + " " + _y);
                //}
                this.grid[_y][_x].material.color.setHex(_c, 16);
            }
        }
    }

    getPixelColour(_x,_y)
    {
        console.log(_x + " " + _y + " => " + this.grid[_y][_x].material.color.getHexString());
        return this.grid[_y][_x].material.color.getHexString();
    }

    getPixelColourR(_x,_y)
    {
        return Math.floor(this.grid[_y][_x].material.color.r * 255);
    }

    getPixelColourG(_x,_y)
    {
        return Math.floor(this.grid[_y][_x].material.color.g * 255);
    }

    getPixelColourB(_x,_y)
    {
        return Math.floor(this.grid[_y][_x].material.color.b * 255);
    }

}

export { Panel };